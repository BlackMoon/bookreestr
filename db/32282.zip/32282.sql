﻿-- Скрипт сгенерирован Devart dbForge Studio for MySQL, Версия 5.0.97.1
-- Домашняя страница продукта: http://www.devart.com/ru/dbforge/mysql/studio
-- Дата скрипта: 06.06.2014 1:05:11
-- Версия сервера: 5.6.19
-- Версия клиента: 4.1

-- 
-- Отключение внешних ключей
-- 
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;

-- 
-- Установка кодировки, с использованием которой клиент будет посылать запросы на сервер
--
SET NAMES 'utf8';

-- 
-- Установка базы данных по умолчанию
--
USE `32282`;

--
-- Описание для таблицы books
--
DROP TABLE IF EXISTS books;
CREATE TABLE books (
  id INT(11) NOT NULL AUTO_INCREMENT,
  name VARCHAR(50) NOT NULL COMMENT 'Название',
  author VARCHAR(255) NOT NULL COMMENT 'Автор(ы)',
  `year` INT(4) NOT NULL COMMENT 'Год выпуска',
  publish VARCHAR(255) DEFAULT NULL COMMENT 'Издательство',
  subjectid INT(11) DEFAULT NULL,
  PRIMARY KEY (id),
  UNIQUE INDEX name (name)
)
ENGINE = MYISAM
AUTO_INCREMENT = 1
CHARACTER SET utf8
COLLATE utf8_general_ci
COMMENT = 'Книги';

--
-- Описание для таблицы readers
--
DROP TABLE IF EXISTS readers;
CREATE TABLE readers (
  id INT(11) NOT NULL AUTO_INCREMENT,
  lastname VARCHAR(255) NOT NULL,
  firstname VARCHAR(255) NOT NULL,
  middlename VARCHAR(255) DEFAULT NULL,
  birthday DATE DEFAULT NULL,
  PRIMARY KEY (id)
)
ENGINE = MYISAM
AUTO_INCREMENT = 1
CHARACTER SET utf8
COLLATE utf8_general_ci
ROW_FORMAT = FIXED;

--
-- Описание для таблицы reestr
--
DROP TABLE IF EXISTS reestr;
CREATE TABLE reestr (
  id INT(11) NOT NULL AUTO_INCREMENT,
  bookid INT(11) NOT NULL,
  readerid INT(11) NOT NULL,
  startdate DATE DEFAULT NULL,
  enddate DATE DEFAULT NULL,
  PRIMARY KEY (id)
)
ENGINE = MYISAM
AUTO_INCREMENT = 1
CHARACTER SET utf8
COLLATE utf8_general_ci;

--
-- Описание для таблицы subjects
--
DROP TABLE IF EXISTS subjects;
CREATE TABLE subjects (
  id INT(11) NOT NULL AUTO_INCREMENT,
  name VARCHAR(50) NOT NULL,
  PRIMARY KEY (id)
)
ENGINE = MYISAM
AUTO_INCREMENT = 1
CHARACTER SET utf8
COLLATE utf8_general_ci
COMMENT = 'Тематики';

--
-- Описание для таблицы users
--
DROP TABLE IF EXISTS users;
CREATE TABLE users (
  id INT(11) NOT NULL AUTO_INCREMENT,
  login VARCHAR(255) NOT NULL,
  `password` VARCHAR(255) NOT NULL,
  salt VARCHAR(255) DEFAULT NULL,
  lastname VARCHAR(255) NOT NULL,
  firstname VARCHAR(255) NOT NULL,
  middlename VARCHAR(255) NOT NULL,
  isadmin INT(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (id),
  UNIQUE INDEX login (login)
)
ENGINE = MYISAM
AUTO_INCREMENT = 13
AVG_ROW_LENGTH = 4611
CHARACTER SET utf8
COLLATE utf8_general_ci
ROW_FORMAT = FIXED;

-- 
-- Вывод данных для таблицы books
--
-- Таблица `32282`.books не содержит данных

-- 
-- Вывод данных для таблицы readers
--
-- Таблица `32282`.readers не содержит данных

-- 
-- Вывод данных для таблицы reestr
--
-- Таблица `32282`.reestr не содержит данных

-- 
-- Вывод данных для таблицы subjects
--
-- Таблица `32282`.subjects не содержит данных

-- 
-- Вывод данных для таблицы users
--
INSERT INTO users VALUES 
  (1, 'admin', 'ece17a9d98d1fb03a4595e4c74be0c7e2427e79d87643f90a907985d41c405dc', '295b5c5251e555b1', 'Админов', 'Админ', 'Админович', 1),
  (3, 'user', '3df44eaa0a833c50107a524c7c70a2262efdfcb3b0c08b8194565dbcdbc8dea2', '6d997b7d13b1b826', 'Пользователев', 'Пользователь', 'Пользователевич', 0);

-- 
-- Включение внешних ключей
-- 
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;