﻿-- Скрипт сгенерирован Devart dbForge Studio for MySQL, Версия 5.0.97.1
-- Домашняя страница продукта: http://www.devart.com/ru/dbforge/mysql/studio
-- Дата скрипта: 06.06.2014 23:49:37
-- Версия сервера: 5.6.19
-- Версия клиента: 4.1

-- 
-- Отключение внешних ключей
-- 
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;

-- 
-- Установка кодировки, с использованием которой клиент будет посылать запросы на сервер
--
SET NAMES 'utf8';

-- 
-- Установка базы данных по умолчанию
--
USE `32282`;

--
-- Описание для таблицы books
--
DROP TABLE IF EXISTS books;
CREATE TABLE books (
  id INT(11) NOT NULL AUTO_INCREMENT,
  name VARCHAR(50) NOT NULL COMMENT 'Название',
  author VARCHAR(255) NOT NULL COMMENT 'Автор(ы)',
  `year` INT(4) NOT NULL COMMENT 'Год выпуска',
  publish VARCHAR(255) DEFAULT NULL COMMENT 'Издательство',
  subjectid INT(11) DEFAULT NULL,
  PRIMARY KEY (id),
  INDEX FK_0334bbe6fec943f8b3d118f5052 (subjectid),
  INDEX FK_0426d3b4f66a475ebaf71d94b35 (subjectid),
  INDEX FK_04a89732438c40d2842172e3109 (subjectid),
  INDEX FK_0ab523b3e4324fc590a1c208a4e (subjectid),
  INDEX FK_0dad3c15e5d2428ba105714b1d1 (subjectid),
  INDEX FK_12ec9eb8473741c9a150321b74f (subjectid),
  INDEX FK_15813ec2e4f5447a8d11d0ec4b2 (subjectid),
  INDEX FK_1b6fe0b668684f2a99d880270e8 (subjectid),
  INDEX FK_1dda651de6e8437f946e3971df1 (subjectid),
  INDEX FK_1e48f9e6b8b142b88610294d5d5 (subjectid),
  INDEX FK_2307b42618194099835eb3fb34c (subjectid),
  INDEX FK_25d9f883d36f4290abdf08197ce (subjectid),
  INDEX FK_293daa04d32b4b0c99ed9672465 (subjectid),
  INDEX FK_2a3e0280d7dc4225a6e94855773 (subjectid),
  INDEX FK_2b063d2bc10c4ef8b9439e0c34f (subjectid),
  INDEX FK_2bb57ba63c5a4da1957ede68d35 (subjectid),
  INDEX FK_2ee722191fb048be80457d570c2 (subjectid),
  INDEX FK_2fb69b821e804fe491646dac3e2 (subjectid),
  INDEX FK_30ce2f35b40247199de5ee69eb4 (subjectid),
  INDEX FK_3bd9d4076047478d9dd3b764b07 (subjectid),
  INDEX FK_420cd005fcc14be0ae9af523808 (subjectid),
  INDEX FK_44222b21111c4542aac942ae6e7 (subjectid),
  INDEX FK_47cbef13e2484967a845d46a20a (subjectid),
  INDEX FK_4a07abdb31da429bb3b361d5ef1 (subjectid),
  INDEX FK_521ad220cef94636b21df140af2 (subjectid),
  INDEX FK_5593d107418b46d29a2b865589a (subjectid),
  INDEX FK_58108ccdebcc489988bbec17cf5 (subjectid),
  INDEX FK_5aa7ce4dda2b466f8f07c79aec8 (subjectid),
  INDEX FK_5f1daa29ef59480a8c851e5c12e (subjectid),
  INDEX FK_5f99a65d18e442caadc2f067375 (subjectid),
  INDEX FK_6802f1c9f92746d6b1035404c77 (subjectid),
  INDEX FK_69597a4b01814ac7bad9f215fe9 (subjectid),
  INDEX FK_6c1665e9a2ce41a28f0afa7abfd (subjectid),
  INDEX FK_6d87b4813ffe4498b49f51d0506 (subjectid),
  INDEX FK_7534750d390e41e3afd708a5aa8 (subjectid),
  INDEX FK_77d6f7fec3594c9db993d7b4767 (subjectid),
  INDEX FK_7f24fb8f89c34046aac73cd3672 (subjectid),
  INDEX FK_888c849020c4415d913188d5ca8 (subjectid),
  INDEX FK_8d0f384174c144a6a268a6cd6dd (subjectid),
  INDEX FK_924ab1db0f494b1dbb42624d970 (subjectid),
  INDEX FK_962695f81ae14b268cde1d65e6e (subjectid),
  INDEX FK_997f1a35dd4046aeb993e8be4a7 (subjectid),
  INDEX FK_9fa259fa621d4f0699ec1f62d6a (subjectid),
  INDEX FK_a256637d61b4432bbaec75cfa66 (subjectid),
  INDEX FK_a65e04ba85124183bf7439f41da (subjectid),
  INDEX FK_aa1cf3343daf44249f6f04816f9 (subjectid),
  INDEX FK_af083da8c0a440f5b9bbf87dc6f (subjectid),
  INDEX FK_bf1e0ca2a857462e8be7a5d82a5 (subjectid),
  INDEX FK_c2b7bf13b5114d4685adc32359e (subjectid),
  INDEX FK_c704ca16313945ccbd379c28ad6 (subjectid),
  INDEX FK_cca332ae82724f5f8bee7c6e6d8 (subjectid),
  INDEX FK_cd273bf5e82e48d2ac703d00c8a (subjectid),
  INDEX FK_cd677f20b12e44bb9dcde5937d6 (subjectid),
  INDEX FK_db4789660fe04d2fa1dd2644853 (subjectid),
  INDEX FK_dbede5f29cf6463797b4fdff7e4 (subjectid),
  INDEX FK_dcb649a9a43241428bc6ad7f051 (subjectid),
  INDEX FK_e85afab3d5424ba09cff49ed684 (subjectid),
  INDEX FK_eb957703f1e14cd9882a8dab90d (subjectid),
  INDEX FK_f0fcb870510d4bbebc2b258a682 (subjectid),
  INDEX FK_f69e1fee38ce4db9b37d73e9e88 (subjectid),
  INDEX FK_fbd8e72f722e4863889e9e67902 (subjectid),
  INDEX FK_fd6e208b3904415899c0e37eab3 (subjectid),
  UNIQUE INDEX name (name)
)
ENGINE = MYISAM
AUTO_INCREMENT = 13
AVG_ROW_LENGTH = 80
CHARACTER SET utf8
COLLATE utf8_general_ci
COMMENT = 'Книги';

--
-- Описание для таблицы readers
--
DROP TABLE IF EXISTS readers;
CREATE TABLE readers (
  id INT(11) NOT NULL AUTO_INCREMENT,
  lastname VARCHAR(255) NOT NULL,
  firstname VARCHAR(255) NOT NULL,
  middlename VARCHAR(255) DEFAULT NULL,
  birthday DATE DEFAULT NULL,
  midllename VARCHAR(255) DEFAULT NULL,
  PRIMARY KEY (id)
)
ENGINE = MYISAM
AUTO_INCREMENT = 12
AVG_ROW_LENGTH = 3076
CHARACTER SET utf8
COLLATE utf8_general_ci
ROW_FORMAT = FIXED;

--
-- Описание для таблицы reestr
--
DROP TABLE IF EXISTS reestr;
CREATE TABLE reestr (
  id INT(11) NOT NULL AUTO_INCREMENT,
  bookid INT(11) NOT NULL,
  readerid INT(11) NOT NULL,
  startdate DATE DEFAULT NULL,
  enddate DATE DEFAULT NULL,
  PRIMARY KEY (id),
  INDEX FK_07e2f559b1334debb273fe5940f (readerid),
  INDEX FK_08e95464d4634378992e53dcb25 (readerid),
  INDEX FK_0e12f17bca49436eaa654ef4d49 (readerid),
  INDEX FK_10f450c108c0491b8cc6984dc6a (readerid),
  INDEX FK_1187195dcbfc41b4bf50ca02973 (readerid),
  INDEX FK_1e11ccc267ca4ce4b8076e82d27 (bookid),
  INDEX FK_22101ba7a557483f941b7ae2189 (bookid),
  INDEX FK_2390993e58ed47229c66a3837b6 (bookid),
  INDEX FK_239a31a8bca84f3c919255521e7 (bookid),
  INDEX FK_25b252c16b084ca58381de22792 (readerid),
  INDEX FK_29f342b65783486c91c5318987f (bookid),
  INDEX FK_2b3772d15d8f4adbb3c7dd881f5 (readerid),
  INDEX FK_2c28563998bf4c0d9888c062f2d (bookid),
  INDEX FK_2cfa6a19db654e71894eaafd0ec (bookid),
  INDEX FK_305da3e26ba44bec9d5a262e4ac (bookid),
  INDEX FK_35e3c0bdbca54f71835bfb705d4 (bookid),
  INDEX FK_3883da53633449839a941ab20b6 (readerid),
  INDEX FK_3ae73e3dc810432c9cb196dff01 (readerid),
  INDEX FK_42481151666f4d518d4d4814fbb (bookid),
  INDEX FK_4723c9e5796043cf946f286aec8 (bookid),
  INDEX FK_4944919940694cc19c2fdfda21f (bookid),
  INDEX FK_4a9de3ca3e164c0faf063eb1020 (bookid),
  INDEX FK_5246a9d7a3624fcf992198a3693 (bookid),
  INDEX FK_57c921b0ba9a4fa18c4b91d3b41 (readerid),
  INDEX FK_5abc7e713e4d4ad0a282533827c (bookid),
  INDEX FK_5ccc06b88b824f1e969bfc5bed8 (readerid),
  INDEX FK_5e1b32cb6a09452cbf92f5bac65 (bookid),
  INDEX FK_60ce0dbdbfbc484584827c6b0c6 (readerid),
  INDEX FK_61b5f8c0b2f44d19902761f1395 (bookid),
  INDEX FK_65b3fc06a58a478bab6575b1c0e (readerid),
  INDEX FK_694c730dcae74d649ac790b9b12 (bookid),
  INDEX FK_6ec21a95686f4d789aef2dddc69 (bookid),
  INDEX FK_786cee75e84d49aabb814cad3c4 (bookid),
  INDEX FK_8b6f2ca27d7d4ae08a7cfdcafb6 (bookid),
  INDEX FK_8d797729ba6d44269d3b1fddf32 (readerid),
  INDEX FK_8dc0b340764b4d4fb35710ed949 (readerid),
  INDEX FK_8e38424de6354e32ae80dd72f07 (readerid),
  INDEX FK_8f05bede86e64cf3b209f398951 (readerid),
  INDEX FK_960e84159f3049b49e39f8e2161 (readerid),
  INDEX FK_9783cc57dc2e4585943a61893c6 (bookid),
  INDEX FK_a354698cfa4a4e318e996bde689 (bookid),
  INDEX FK_a420e7a7c151443c92fdc96aafa (readerid),
  INDEX FK_a76be1eadf6b4ff997c8d380bdc (bookid),
  INDEX FK_a777a6e2697b431cb83388612d8 (bookid),
  INDEX FK_a90d151d5a144307ab67107e89a (readerid),
  INDEX FK_ae633f2dcee642beb48a856e93e (readerid),
  INDEX FK_b50950ab50624be080ffe9c4d79 (bookid),
  INDEX FK_ba1e9902fc1a429d95d2c4938b6 (readerid),
  INDEX FK_ba3151e1136e472c88da4b27012 (readerid),
  INDEX FK_bc961ba49f344e4f9269208af3c (readerid),
  INDEX FK_c511e351ec144e2d8bceb0c3d9c (readerid),
  INDEX FK_c5b50fdc03d147dcb731559a59d (bookid),
  INDEX FK_c6b99d0aee6b446a8c8f636e172 (bookid),
  INDEX FK_d31b84c6b01f479c9c8da6b92ba (bookid),
  INDEX FK_d56b7cd5f6844e92a293d793cf3 (readerid),
  INDEX FK_d690d267111c40e090ca0e0e55c (bookid),
  INDEX FK_d77309780c134cb1966260c5637 (readerid),
  INDEX FK_db9f555e49ae400388b31bc5d55 (bookid),
  INDEX FK_dd4e0bb14a054b3792a1c584543 (readerid),
  INDEX FK_de23886e1b644d8695c9cbbf261 (bookid),
  INDEX FK_f1375a05b98d4fddab280b583b3 (readerid),
  INDEX FK_f3986f5952b44a48a61cd41558b (bookid),
  INDEX FK_f52967f6434b4080b9ec8fff0f6 (readerid)
)
ENGINE = MYISAM
AUTO_INCREMENT = 12
AVG_ROW_LENGTH = 19
CHARACTER SET utf8
COLLATE utf8_general_ci;

--
-- Описание для таблицы subjects
--
DROP TABLE IF EXISTS subjects;
CREATE TABLE subjects (
  id INT(11) NOT NULL AUTO_INCREMENT,
  name VARCHAR(50) NOT NULL,
  PRIMARY KEY (id),
  UNIQUE INDEX name (name)
)
ENGINE = MYISAM
AUTO_INCREMENT = 23
AVG_ROW_LENGTH = 27
CHARACTER SET utf8
COLLATE utf8_general_ci
COMMENT = 'Тематики';

--
-- Описание для таблицы users
--
DROP TABLE IF EXISTS users;
CREATE TABLE users (
  id INT(11) NOT NULL AUTO_INCREMENT,
  login VARCHAR(255) NOT NULL,
  `password` VARCHAR(255) NOT NULL,
  salt VARCHAR(255) DEFAULT NULL,
  lastname VARCHAR(255) NOT NULL,
  firstname VARCHAR(255) NOT NULL,
  middlename VARCHAR(255) NOT NULL,
  isadmin INT(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (id),
  UNIQUE INDEX login (login)
)
ENGINE = MYISAM
AUTO_INCREMENT = 13
AVG_ROW_LENGTH = 4611
CHARACTER SET utf8
COLLATE utf8_general_ci
ROW_FORMAT = FIXED;

-- 
-- Вывод данных для таблицы books
--
INSERT INTO books VALUES 
  (1, 'Робинзон Крузо', 'Д. Дефо', 1990, 'Стрела', 1),
  (3, 'Последний из Магикан', 'Дж. Ф. Купер', 1999, 'Роспресс', 1),
  (4, 'Мастер и Маргарита', 'М. Булгаков', 1996, '', 15),
  (5, 'Война и Мир', 'Л. Толстой', 1980, '', 15),
  (6, 'Рассказы', 'О''Генри', 1998, '', 13),
  (7, 'Таинственный остров', 'Ж. Верн', 2002, 'Пресс', 13),
  (8, 'Собака Баскервиллей', 'А. Конан-Дойль', 2003, 'Пресс', 14),
  (9, 'Принц и нищий', 'М. Твен', 2002, 'Пресс', 15),
  (10, 'Волшебник Изумрудного города', 'А. Волков', 2005, 'Пресс', 21),
  (11, 'Властелин колец', 'Д. Толкиен', 2008, 'Аист пресс', 22),
  (12, 'Тайна заброшенной башни', 'С. Кинг', 2001, 'Пресс', 1);

-- 
-- Вывод данных для таблицы readers
--
INSERT INTO readers VALUES 
  (2, 'Иванов', 'Иван', 'Иванович', NULL, NULL),
  (3, 'Петров', 'Петр', 'Петрович', NULL, NULL),
  (4, 'Сидоров', 'Сидор', 'Сидорович', NULL, NULL),
  (5, 'Карпов', 'Иван', 'Кузьмич', '2014-06-02', NULL),
  (6, 'Кораблев', 'Сергей', 'Николаевич', '2014-06-19', NULL),
  (7, 'Плотникова', 'Ирина', 'Андреевна', NULL, NULL),
  (8, 'Хакимьянова', 'Гузель', 'Фаридовна', NULL, NULL),
  (9, 'Валлева', 'Анна', 'Петровна', NULL, NULL),
  (10, 'Алешко', 'Владимир', 'Игоревич', NULL, NULL),
  (11, 'Пирогова', 'Мария', 'Борисовна', NULL, NULL);

-- 
-- Вывод данных для таблицы reestr
--
INSERT INTO reestr VALUES 
  (1, 1, 10, '2014-05-06', '2014-06-10'),
  (2, 4, 2, '2014-06-01', '2014-06-10'),
  (3, 5, 10, '2014-05-01', '2014-05-10'),
  (4, 12, 10, '2014-06-02', '2014-06-12'),
  (5, 5, 9, '2014-05-12', '2014-05-22'),
  (6, 11, 6, '2014-06-15', '2014-06-24'),
  (7, 6, 4, '2014-04-01', '2014-04-10'),
  (8, 7, 7, '2014-03-02', '2014-03-12'),
  (9, 10, 5, '2014-05-31', '2014-06-11'),
  (10, 8, 9, '2014-03-02', '2014-04-17'),
  (11, 9, 8, '2014-05-13', '2014-05-24');

-- 
-- Вывод данных для таблицы subjects
--
INSERT INTO subjects VALUES 
  (1, 'Ужасы'),
  (2, 'Фантастика'),
  (13, 'Приключения'),
  (14, 'Детективы'),
  (15, 'Классика'),
  (16, 'Мистика'),
  (17, 'История'),
  (18, 'Здоровье'),
  (19, 'Политика'),
  (20, 'Путешествия'),
  (21, 'Сказки'),
  (22, 'Фентези');

-- 
-- Вывод данных для таблицы users
--
INSERT INTO users VALUES 
  (1, 'admin', 'ece17a9d98d1fb03a4595e4c74be0c7e2427e79d87643f90a907985d41c405dc', '295b5c5251e555b1', 'Админов', 'Админ', 'Админович', 1),
  (3, 'user', '3df44eaa0a833c50107a524c7c70a2262efdfcb3b0c08b8194565dbcdbc8dea2', '6d997b7d13b1b826', 'Пользователев', 'Пользователь', 'Пользователевич', 0);

-- 
-- Включение внешних ключей
-- 
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;