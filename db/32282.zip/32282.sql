﻿-- Скрипт сгенерирован Devart dbForge Studio for MySQL, Версия 6.0.568.0
-- Домашняя страница продукта: http://www.devart.com/ru/dbforge/mysql/studio
-- Дата скрипта: 06.06.2014 17:46:00
-- Версия сервера: 5.6.19
-- Версия клиента: 4.1

-- 
-- Отключение внешних ключей
-- 
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;

-- 
-- Установка кодировки, с использованием которой клиент будет посылать запросы на сервер
--
SET NAMES 'utf8';

-- 
-- Установка базы данных по умолчанию
--
USE `32282`;

--
-- Описание для таблицы books
--
DROP TABLE IF EXISTS books;
CREATE TABLE books (
  id INT(11) NOT NULL AUTO_INCREMENT,
  name VARCHAR(50) NOT NULL COMMENT 'Название',
  author VARCHAR(255) NOT NULL COMMENT 'Автор(ы)',
  year INT(4) NOT NULL COMMENT 'Год выпуска',
  publish VARCHAR(255) DEFAULT NULL COMMENT 'Издательство',
  subjectid INT(11) DEFAULT NULL,
  PRIMARY KEY (id),
  UNIQUE INDEX name (name)
)
ENGINE = MYISAM
AUTO_INCREMENT = 3
AVG_ROW_LENGTH = 92
CHARACTER SET utf8
COLLATE utf8_general_ci
COMMENT = 'Книги';

--
-- Описание для таблицы readers
--
DROP TABLE IF EXISTS readers;
CREATE TABLE readers (
  id INT(11) NOT NULL AUTO_INCREMENT,
  lastname VARCHAR(255) NOT NULL,
  firstname VARCHAR(255) NOT NULL,
  middlename VARCHAR(255) DEFAULT NULL,
  birthday DATE DEFAULT NULL,
  midllename VARCHAR(255) DEFAULT NULL,
  PRIMARY KEY (id)
)
ENGINE = MYISAM
AUTO_INCREMENT = 12
AVG_ROW_LENGTH = 3076
CHARACTER SET utf8
COLLATE utf8_general_ci
ROW_FORMAT = FIXED;

--
-- Описание для таблицы reestr
--
DROP TABLE IF EXISTS reestr;
CREATE TABLE reestr (
  id INT(11) NOT NULL AUTO_INCREMENT,
  bookid INT(11) NOT NULL,
  readerid INT(11) NOT NULL,
  startdate DATE DEFAULT NULL,
  enddate DATE DEFAULT NULL,
  PRIMARY KEY (id)
)
ENGINE = MYISAM
AUTO_INCREMENT = 2
AVG_ROW_LENGTH = 19
CHARACTER SET utf8
COLLATE utf8_general_ci;

--
-- Описание для таблицы reestrs
--
DROP TABLE IF EXISTS reestrs;
CREATE TABLE reestrs (
  id INT(11) NOT NULL AUTO_INCREMENT,
  endDate DATETIME DEFAULT NULL,
  startDate DATETIME DEFAULT NULL,
  PRIMARY KEY (id)
)
ENGINE = INNODB
AUTO_INCREMENT = 1
CHARACTER SET utf8
COLLATE utf8_general_ci;

--
-- Описание для таблицы subjects
--
DROP TABLE IF EXISTS subjects;
CREATE TABLE subjects (
  id INT(11) NOT NULL AUTO_INCREMENT,
  name VARCHAR(50) NOT NULL,
  PRIMARY KEY (id)
)
ENGINE = MYISAM
AUTO_INCREMENT = 13
AVG_ROW_LENGTH = 26
CHARACTER SET utf8
COLLATE utf8_general_ci
COMMENT = 'Тематики';

--
-- Описание для таблицы users
--
DROP TABLE IF EXISTS users;
CREATE TABLE users (
  id INT(11) NOT NULL AUTO_INCREMENT,
  login VARCHAR(255) NOT NULL,
  password VARCHAR(255) NOT NULL,
  salt VARCHAR(255) DEFAULT NULL,
  lastname VARCHAR(255) NOT NULL,
  firstname VARCHAR(255) NOT NULL,
  middlename VARCHAR(255) NOT NULL,
  isadmin INT(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (id),
  UNIQUE INDEX login (login)
)
ENGINE = MYISAM
AUTO_INCREMENT = 13
AVG_ROW_LENGTH = 4611
CHARACTER SET utf8
COLLATE utf8_general_ci
ROW_FORMAT = FIXED;

-- 
-- Вывод данных для таблицы books
--
INSERT INTO books VALUES
(1, 'Робинзон Крузо', 'Д. Дефо', 1990, 'Стрела', 1);

-- 
-- Вывод данных для таблицы readers
--
INSERT INTO readers VALUES
(2, 'Иванов', 'Иван', 'Иванович', NULL, NULL),
(3, 'Петров', 'Петр', 'Петрович', NULL, NULL),
(4, 'Сидоров', 'Сидор', 'Сидорович', NULL, NULL),
(5, 'Карпов', 'Иван', 'Кузьмич', '2014-06-02', NULL),
(6, 'Кораблев', 'Сергей', 'Николаевич', '2014-06-19', NULL),
(7, 'Плотникова', 'Ирина', 'Андреевна', NULL, NULL),
(8, 'Хакимьянова', 'Гузель', 'Фаридовна', NULL, NULL),
(9, 'Валлева', 'Анна', 'Петровна', NULL, NULL),
(10, 'Алешко', 'Владимир', 'Игоревич', NULL, NULL),
(11, 'Пирогова', 'Мария', 'Борисовна', NULL, NULL);

-- 
-- Вывод данных для таблицы reestr
--
INSERT INTO reestr VALUES
(1, 1, 1, '2014-06-05', '2014-06-15');

-- 
-- Вывод данных для таблицы reestrs
--

-- Таблица `32282`.reestrs не содержит данных

-- 
-- Вывод данных для таблицы subjects
--
INSERT INTO subjects VALUES
(1, 'Классика'),
(2, 'Фантастика'),
(3, 'Ужасы'),
(4, 'Детективы'),
(5, 'Мистика'),
(6, 'Здоровье'),
(7, 'История'),
(8, 'Политика'),
(9, 'Музыка'),
(11, 'Биография');

-- 
-- Вывод данных для таблицы users
--
INSERT INTO users VALUES
(1, 'admin', 'ece17a9d98d1fb03a4595e4c74be0c7e2427e79d87643f90a907985d41c405dc', '295b5c5251e555b1', 'Админов', 'Админ', 'Админович', 1),
(3, 'user', '3df44eaa0a833c50107a524c7c70a2262efdfcb3b0c08b8194565dbcdbc8dea2', '6d997b7d13b1b826', 'Пользователев', 'Пользователь', 'Пользователевич', 0);

-- 
-- Включение внешних ключей
-- 
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;